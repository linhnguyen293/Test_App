
import UIKit
import PlaygroundSupport
func printRightTriangle(enter rows: Int = 10, symbol: Character){
    guard rows <= 100, rows > 0 else {
        print("Input invalid rows!")
        return
    }
    for i in 0...rows{
        for _ in stride(from: rows, to: i, by: -1){
            print( terminator : " ")
        }
        for _ in 0...i{
            print(symbol,terminator : "")
        }
        print(" ")
        
    }
}
printRightTriangle(enter: 28, symbol: "#")
